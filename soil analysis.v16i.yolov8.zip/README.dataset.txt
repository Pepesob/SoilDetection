# soil analysis > 2022-07-03 7:04pm
https://universe.roboflow.com/universty/soil-analysis

Provided by a Roboflow user
License: CC BY 4.0

